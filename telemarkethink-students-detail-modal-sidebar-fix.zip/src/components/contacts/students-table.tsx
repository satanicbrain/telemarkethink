"use client";

import { useEffect, useMemo, useState } from "react";
import { Button } from "@/src/components/ui/button";
import { Card, CardContent } from "@/src/components/ui/card";
import { cn } from "@/src/lib/cn";

type StudentRow = {
  id: string;
  student_name: string;
  nick_name: string | null;
  parent: string | null;
  birthday: string | null;
  gender: string | null;
  address: string | null;
  telephone: string;
  email: string | null;
  created_at: string;
  birthday_date: string | null;
  whatsapp_opt_in: boolean;
  email_opt_in: boolean;
  age: number | null;
};

function Badge({ active, label }: { active: boolean; label: string }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-full px-2.5 py-1 text-xs font-semibold",
        active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"
      )}
    >
      {label}
    </span>
  );
}

function formatDate(value: string | null, withTime = false) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("id-ID", withTime
    ? {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }
    : {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
      <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-400">{label}</div>
      <div className="mt-1 text-sm text-slate-700">{value || "-"}</div>
    </div>
  );
}

export function StudentsTable({ rows }: { rows: StudentRow[] }) {
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<Record<string, string>>({});
  const [selectedRow, setSelectedRow] = useState<StudentRow | null>(null);

  const sortedRows = useMemo(() => rows, [rows]);

  useEffect(() => {
    if (!selectedRow) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSelectedRow(null);
      }
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);

    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [selectedRow]);

  async function sendWhatsApp(row: StudentRow) {
    setLoadingId(`wa-${row.id}`);
    setFeedback((current) => ({ ...current, [row.id]: "" }));

    try {
      const response = await fetch("/api/wa/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: row.telephone,
          message: `Halo ${row.parent || row.student_name}, salam hangat dari tim kami. Kami siap membantu kebutuhan informasi Anda dengan singkat dan jelas.`,
        }),
      });

      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error || "Gagal kirim WhatsApp.");
      }

      setFeedback((current) => ({ ...current, [row.id]: "WhatsApp berhasil dikirim." }));
    } catch (error) {
      setFeedback((current) => ({
        ...current,
        [row.id]: error instanceof Error ? error.message : "Gagal kirim WhatsApp.",
      }));
    } finally {
      setLoadingId(null);
    }
  }

  async function sendEmail(row: StudentRow) {
    if (!row.email) return;

    setLoadingId(`email-${row.id}`);
    setFeedback((current) => ({ ...current, [row.id]: "" }));

    try {
      const response = await fetch("/api/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: row.email,
          subject: `Halo ${row.parent || row.student_name}, salam hangat dari tim kami`,
          html: `<p>Halo ${row.parent || row.student_name},</p><p>Kami siap membantu kebutuhan informasi Anda dengan penjelasan yang ringkas, rapi, dan jelas.</p><p>Salam hangat,<br/>Tim TelemarkeTHINK</p>`,
        }),
      });

      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error || "Gagal kirim email.");
      }

      setFeedback((current) => ({ ...current, [row.id]: "Email berhasil dikirim." }));
    } catch (error) {
      setFeedback((current) => ({
        ...current,
        [row.id]: error instanceof Error ? error.message : "Gagal kirim email.",
      }));
    } finally {
      setLoadingId(null);
    }
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="min-w-[1320px] text-left text-sm">
          <thead className="text-slate-500">
            <tr className="border-b border-slate-100">
              <th className="pb-3 pr-4 font-medium">Student</th>
              <th className="pb-3 pr-4 font-medium">Nick</th>
              <th className="pb-3 pr-4 font-medium">Parent</th>
              <th className="pb-3 pr-4 font-medium">Birthday</th>
              <th className="pb-3 pr-4 font-medium">Umur</th>
              <th className="pb-3 pr-4 font-medium">Gender</th>
              <th className="pb-3 pr-4 font-medium">Address</th>
              <th className="pb-3 pr-4 font-medium">Telephone</th>
              <th className="pb-3 pr-4 font-medium">Email</th>
              <th className="pb-3 pr-4 font-medium">Created</th>
              <th className="pb-3 pr-4 font-medium">Consent</th>
              <th className="pb-3 pr-4 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedRows.map((row) => {
              const waLoading = loadingId === `wa-${row.id}`;
              const emailLoading = loadingId === `email-${row.id}`;

              return (
                <tr
                  key={row.id}
                  tabIndex={0}
                  role="button"
                  onClick={() => setSelectedRow(row)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault();
                      setSelectedRow(row);
                    }
                  }}
                  className="cursor-pointer border-b border-slate-100 align-top transition hover:bg-brand-50/40 focus:outline-none focus:ring-2 focus:ring-brand-300"
                >
                  <td className="py-4 pr-4">
                    <div className="font-semibold text-slate-900">{row.student_name}</div>
                    <div className="mt-1 text-xs text-slate-500">Klik untuk lihat detail</div>
                  </td>
                  <td className="py-4 pr-4 text-slate-600">{row.nick_name || "-"}</td>
                  <td className="py-4 pr-4 text-slate-600">{row.parent || "-"}</td>
                  <td className="py-4 pr-4 text-slate-600">
                    <div>{row.birthday || (row.birthday_date ? formatDate(row.birthday_date) : "-")}</div>
                  </td>
                  <td className="py-4 pr-4 text-slate-600">{row.age ?? "-"}</td>
                  <td className="py-4 pr-4 text-slate-600">{row.gender || "-"}</td>
                  <td className="py-4 pr-4 text-slate-600">
                    <div className="max-w-[220px] whitespace-normal break-words">{row.address || "-"}</div>
                  </td>
                  <td className="py-4 pr-4 text-slate-600">{row.telephone}</td>
                  <td className="py-4 pr-4 text-slate-600">{row.email || "-"}</td>
                  <td className="py-4 pr-4 text-slate-600">{formatDate(row.created_at)}</td>
                  <td className="py-4 pr-4">
                    <div className="flex flex-wrap gap-2">
                      <Badge active={row.whatsapp_opt_in} label={`WA ${row.whatsapp_opt_in ? "Yes" : "No"}`} />
                      <Badge active={row.email_opt_in} label={`Email ${row.email_opt_in ? "Yes" : "No"}`} />
                    </div>
                  </td>
                  <td className="py-4 pr-4">
                    <div className="flex min-w-[180px] flex-col gap-2" onClick={(event) => event.stopPropagation()}>
                      <Button
                        type="button"
                        onClick={() => sendWhatsApp(row)}
                        disabled={!row.whatsapp_opt_in || waLoading}
                        className="justify-center"
                      >
                        {waLoading ? "Mengirim WA..." : "Kirim WA"}
                      </Button>
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={() => sendEmail(row)}
                        disabled={!row.email_opt_in || !row.email || emailLoading}
                        className="justify-center"
                      >
                        {emailLoading ? "Mengirim Email..." : "Kirim Email"}
                      </Button>
                      {feedback[row.id] ? <div className="text-xs text-slate-500">{feedback[row.id]}</div> : null}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedRow ? (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-sm" onClick={() => setSelectedRow(null)} />
          <Card className="relative z-10 max-h-[90vh] w-full max-w-4xl overflow-hidden rounded-[2rem] border-slate-200 shadow-2xl">
            <CardContent className="p-0">
              <div className="border-b border-slate-100 bg-gradient-to-r from-brand-700 via-brand-600 to-brand-500 px-6 py-5 text-white">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-xs uppercase tracking-[0.28em] text-brand-100">Detail siswa</div>
                    <h3 className="mt-2 text-2xl font-semibold">{selectedRow.student_name}</h3>
                    <p className="mt-1 text-sm text-brand-100">
                      {selectedRow.parent ? `Orang tua: ${selectedRow.parent}` : "Profil kontak siswa"}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedRow(null)}
                    className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-xl transition hover:bg-white/20"
                    aria-label="Close detail"
                  >
                    ×
                  </button>
                </div>
              </div>

              <div className="max-h-[calc(90vh-96px)] overflow-y-auto px-6 py-6">
                <div className="mb-6 flex flex-wrap gap-3">
                  <Badge active={selectedRow.whatsapp_opt_in} label={`WhatsApp ${selectedRow.whatsapp_opt_in ? "Opt-in" : "Not Opt-in"}`} />
                  <Badge active={selectedRow.email_opt_in} label={`Email ${selectedRow.email_opt_in ? "Opt-in" : "Not Opt-in"}`} />
                  <Badge active={Boolean(selectedRow.birthday_date)} label={selectedRow.age !== null ? `${selectedRow.age} tahun` : "Umur belum tersedia"} />
                </div>

                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                  <DetailItem label="Nama siswa" value={selectedRow.student_name} />
                  <DetailItem label="Nama panggilan" value={selectedRow.nick_name || "-"} />
                  <DetailItem label="Orang tua" value={selectedRow.parent || "-"} />
                  <DetailItem label="Tanggal lahir" value={selectedRow.birthday || formatDate(selectedRow.birthday_date)} />
                  <DetailItem label="Umur" value={selectedRow.age !== null ? `${selectedRow.age} tahun` : "-"} />
                  <DetailItem label="Gender" value={selectedRow.gender || "-"} />
                  <DetailItem label="Telepon" value={selectedRow.telephone} />
                  <DetailItem label="Email" value={selectedRow.email || "-"} />
                  <DetailItem label="Created at" value={formatDate(selectedRow.created_at, true)} />
                </div>

                <div className="mt-3 grid gap-3 xl:grid-cols-[1.25fr_0.75fr]">
                  <DetailItem label="Alamat" value={selectedRow.address || "-"} />
                  <DetailItem
                    label="Aksi cepat"
                    value="Klik tombol di bawah untuk langsung menghubungi kontak terpilih."
                  />
                </div>

                <div className="mt-6 flex flex-col gap-3 border-t border-slate-100 pt-5 sm:flex-row sm:items-center">
                  <Button
                    type="button"
                    onClick={() => sendWhatsApp(selectedRow)}
                    disabled={!selectedRow.whatsapp_opt_in || loadingId === `wa-${selectedRow.id}`}
                    className="min-w-[180px]"
                  >
                    {loadingId === `wa-${selectedRow.id}` ? "Mengirim WA..." : "Send WA"}
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => sendEmail(selectedRow)}
                    disabled={!selectedRow.email_opt_in || !selectedRow.email || loadingId === `email-${selectedRow.id}`}
                    className="min-w-[180px]"
                  >
                    {loadingId === `email-${selectedRow.id}` ? "Mengirim Email..." : "Send Email"}
                  </Button>
                  <Button type="button" variant="ghost" onClick={() => setSelectedRow(null)}>
                    Tutup
                  </Button>
                </div>

                {feedback[selectedRow.id] ? (
                  <div className="mt-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
                    {feedback[selectedRow.id]}
                  </div>
                ) : null}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}
    </>
  );
}
