import { NextResponse } from "next/server";
import { requireApiUser } from "@/src/lib/auth";
import { getActiveWhatsAppProvider } from "@/src/lib/providers/whatsapp";
import { createSupabaseAdminClient } from "@/src/lib/supabase/admin";
import { renderTemplate } from "@/src/lib/templates/render";
import { sendWhatsAppSchema } from "@/src/lib/validations/send";

export async function POST(request: Request) {
  const auth = await requireApiUser(["admin", "operator"]);
  if (!auth.ok) return NextResponse.json({ error: auth.message }, { status: auth.status });

  const body = await request.json();
  const parsed = sendWhatsAppSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  const admin = createSupabaseAdminClient();
  const providerContext = await getActiveWhatsAppProvider();

  const contact = parsed.data.contactId
    ? (await admin.from("contacts").select("*").eq("id", parsed.data.contactId).single()).data
    : null;

  const template = parsed.data.templateId
    ? (await admin.from("wa_templates").select("*").eq("id", parsed.data.templateId).single()).data
    : null;

  const to = parsed.data.to ?? contact?.phone_e164;
  if (!to) {
    return NextResponse.json({ error: "Target WhatsApp is required." }, { status: 400 });
  }

  const message = template
    ? renderTemplate(template.body_template, {
        name: contact?.full_name ?? "",
        city: contact?.city ?? "",
        product_interest: contact?.product_interest ?? "",
      })
    : parsed.data.message;

  if (!message && !(template?.provider_template_key && providerContext.provider.sendTemplate)) {
    return NextResponse.json({ error: "Message or template is required." }, { status: 400 });
  }

  const result =
    template?.provider_template_key && providerContext.provider.sendTemplate
      ? await providerContext.provider.sendTemplate({
          to,
          templateName: template.provider_template_key,
          languageCode: template.language_code ?? "id",
          variables: [],
          meta: { requestedBy: auth.user.id },
        })
      : await providerContext.provider.sendText({
          to,
          message: message ?? "",
          meta: { requestedBy: auth.user.id },
        });

  await admin.from("message_logs").insert({
    contact_id: contact?.id ?? null,
    channel: "whatsapp",
    provider: providerContext.providerKey,
    provider_message_id: result.providerMessageId ?? null,
    status: result.ok ? "sent" : "failed",
    body_preview: message ?? template?.name ?? "",
    provider_response: result.raw ?? {},
    error_message: result.error ?? null,
    sent_at: result.ok ? new Date().toISOString() : null,
  });

  if (!result.ok) {
    return NextResponse.json({ error: result.error ?? "WhatsApp send failed", raw: result.raw }, { status: 500 });
  }

  return NextResponse.json({ data: result });
}
